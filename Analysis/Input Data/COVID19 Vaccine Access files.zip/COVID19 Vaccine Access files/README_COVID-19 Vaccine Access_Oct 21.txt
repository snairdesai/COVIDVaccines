﻿GENERAL INFORMATION


1. Title of Dataset: COVID-19 Vaccine Access Arrangements


2. Author Information
        A. Principal Investigator Contact Information
                Name: Suerie Moon
                Institution: Global Health Centre, Graduate Institute of International and Development Studies
                Address: Chemin Eugène-Rigot 2A, Case postale 1672, 1211 Geneva 1, Switzerland
                Email: suerie.moon@graduateinstitute.ch ; 


        B. Associates or Co-investigators Contact Information
                Name: Surabhi Agarwal, Adrián Alonso Ruiz, Seraina Laura Kull, Anna Bezruki (former collaborator)
                Institution: Global Health Centre, Graduate Institute of International and Development Studies
                Address: Chemin Eugène-Rigot 2A, Case postale 1672, 1211 Geneva 1, Switzerland
                Email: globalhealthresearch@graduateinstitute.ch 


3. Date of data collection (single date, range, approximate date): approximate range, 2020-07-01-present




4. Information about funding sources that supported the collection of the data: Swiss National Science Foundation




SHARING/ACCESS INFORMATION


1. Licenses/restrictions placed on the data: Open Access, Creative Commons and distributed in accordance with the Creative Commons Attribution Non Commercial International (CC BY-NC 4.0) license, which permits others to distribute, remix, adapt, build upon this work non-commercially, and license their derivative works on different terms, provided the original work is properly cited and the use is non-commercial. Third party material are not included. See: https://creativecommons.org/licenses/by-nc/4.0/ 




2. Recommended citation for this dataset: Global Health Centre. (2021). COVID-19 Vaccine Purchase Agreements. Graduate Institute of International and Development Studies. Retrieved from: https://www.knowledgeportalia.org/covid19-vaccine-arrangements 




DATA & FILE OVERVIEW


1. Data is updated once every month. 


METHODOLOGICAL INFORMATION


1. Description of methods used for collection/generation of data: 
Information on arrangements aggregated from publicly available sources, including news reports (links in dataset). Country population and income information available from the World Bank (www.data.worldbank.org), with exception of Taiwanese data, which is available from the Taiwanese government (www.eng.stat.gov.tw). Clinical trial stage information primarily based on the New York Times’ vaccine tracker (https://www.nytimes.com/interactive/2020/science/coronavirus-vaccine-tracker.html). Information on vaccine approval status is based on UNICEF’s COVID-19 Vaccine Market Dashboard (https://www.unicef.org/supply/covid-19-vaccine-market-dashboard). 


2. Twitter API
The research team is also collecting data on Covid-19 vaccine purchases and donations through Twitter API that facilitates easy access to the tweet texts and metadata of interest. The R package rtweet offers functions to search for and download Twitter data. In this project, the function search_tweets() returned the desired tweets as specified in the search query. Users_data() served to add user-specific data. Data is collected over the past week, but the timeframe can be adjusted by a change to the search query. 
A developer account is needed to gain access to the Twitter API. Thereafter, a project on Twitter’s developer platform link can be started. After the application receives approval, the necessary keys and tokens can be found on the developer platform. The code used in this project is provided together with the dataset and the readme file. If you have any questions or comments, please do not hesitate in contacting us. 
To follow the code, assign the corresponding keys and tokens to objects named consumer_key, consumer_secret, access_token, and access_secret. The code returns an Excel file with the following information for each tweet: date and time, user handle, name, and description, tweet text, URLs in tweet text, tweet’s URL, and location. In the code, multiple independent search queries are carried out and subsequently combined into one dataframe. Including all countries in one single query would have been preferred, but this would exceed the limit of 500 characters. The duplicated tweets are removed before saving the dataset as an Excel file. There are still duplicates of the tweet texts but these have different links embedded in the tweet. To allow for choosing the best source from the output, all variations of the same text with different links are kept. 
Note: This project uses rtweet version 0.7.0. For the documentation see https://www.rdocumentation.org/packages/rtweet/versions/0.7.0. 


DATA-SPECIFIC INFORMATION FOR: [COVID-19_Vaccine_Agreements]


1. Variable List: 
Sheet 1: Primary Arrangements . This sheet contains information on purchasing arrangements made between vaccine developers and other entities (companies, countries, multilateral organizations). 


Vaccine candidate: Vaccine developer name for each vaccine candidate.


Developer Location: Main location/headquarters of each vaccine developer.


Trial Phase: Current phase of the clinical trial - Phase 1/2, Phase 2, Phase 2/3, Phase 3, Terminated, and Approved. When a vaccine has achieved emergency or standard regulatory approval in at least one country, based on UNICEF data, it is categorized as Approved, even if clinical trials are still ongoing. 


1 or 2 doses: Vaccine candidates require 1 or 2 doses, depending on the candidate. 


Arrangement Type: "Multilateral Purchase" denotes arrangements between multilateral entities such as COVAX or the EU with vaccine developers; "Government Purchase" tracks arrangements between a given country and vaccine developers; "Private Purchase" tracks purchases between private entities and vaccine developers; “Private Donation” tracks direct donations from vaccine developers to other entities; and "Combination" tracks combination manufacturing and purchasing arrangements.


Finalized Commitment: Arrangements that appear to have been confirmed/finalized by their parties are listed as "Yes," those for which the arrangement status is unknown or conflicting information is present are listed as "Unclear", those that are in negotiations are listed as "No" and those that were finalized but have since been canceled are listed as "Terminated".


Manufacturer and/or Distributor: When available, the manufacturer and/or distributor is provided. 


Manufacturer and/or Distributor Primary Location: The primary location/headquarters of the vaccine manufacturer and/or distributor. For arrangements where separate manufacturers and distributors are listed, only the location for the manufacturer is listed here. 


Doses committed (in millions): Doses committed in the arrangement, in millions. Does not include options for purchases of additional doses that are included in some contracts (these are logged, when present, in the "Notes" column). 


Timeline : Free text tracking of proposed timeline for delivery of doses at the time of the arrangement.


Price (in USD millions): The reported confirmed or estimated price of the purchase agreements, directly as reported or calculated based on reported price/dose (calculation method noted in the “Notes” column). If provided in currency other than USD, converted based on conversion rate of the day of the reporting. 


Price/Dose (in USD): The reported confirmed or estimated price per dose of the purchase agreements, directly as reported or calculated based on reported total price (calculation method noted in the “Notes” column). If provided in currency other than USD, converted based on conversion rate of the day of the reporting.


Recipient: Country, territory, or multilateral entity that will receive the vaccines from the arrangement.


Recipient Region: Region for the recipient, as defined by the World Bank.


Recipient Income Level: Income level as defined by the World Bank. Income level for African Union and European Union as if participating countries were a single entity.


GNI/capita (Atlas method) (current US$): For the Recipient, based on World Bank data. 


GNI, Atlas method (current US$) : For the Recipient, based on World Bank data (Atlas method).


Population: Based on World Bank data.


Population (in millions): Rounded population size.


Doses/Capita: Number of committed doses per capita of Recipient.


Proportion of population: Proportion of the population that would be covered by the doses committed (taking into account the number of doses required for each candidate). 


Notes: Free text tracking of relevant information on the arrangements.


Sources: URLs for all sources used for each arrangement.


Sheet 2: Secondary Arrangements. This sheet contains information on secondary purchase arrangements between entities that have already purchased vaccines and secondary entities (recipients) that are receiving these vaccines through purchase or donation. Should a vaccine developer donate doses directly, that is captured in Sheet 1.


Donor: Name of the entity donating the vaccines


Vaccine candidate: Vaccine developer name for each vaccine candidate.


Developer Location: Main location/headquarters of each vaccine developer.


Trial Phase: Current phase of the clinical trial - Phase 1/2, Phase 2, Phase 2/3, Phase 3, Terminated, and Approved. When a vaccine has achieved emergency or standard regulatory approval in at least one country, based on UNICEF data, it is categorized as Approved, even if clinical trials are still ongoing. 


1 or 2 doses: Vaccine candidates require 1 or 2 doses, depending on the candidate. 


Arrangement Type: Denotes whether the secondary arrangement is a purchase, donation, grant, exchange, or loan. 


Finalized Commitment: Arrangements that appear to have been confirmed/finalized by their parties are listed as "Yes," those for which the arrangement status is unknown or conflicting information is present are listed as "Unclear", those that are in negotiations are listed as "No" and those that were finalized but have since been canceled as listed as "Terminated".


Manufacturer: When available, the manufacturer is provided. 


Manufacturer Primary Location: The primary location/headquarters of the manufacturer. 


Doses Committed (in millions): Number of doses provided in the arrangement, in millions.
Timeline: Free text tracking of proposed timeline for delivery of the first batch of doses at the time of the arrangement. Provided in Month-Year. 


Timeline : Free text tracking of proposed timeline for delivery of doses at the time of the arrangement.


Transfer Level: Denotes whether the transfer is “Secondary” or “Tertiary” transfer, where a secondary transfer is defined as one that is between an entity that has acquired vaccines from a vaccine developer and gives, sells, or exchanges the doses or the money for such doses with another entity, and a tertiary transfer is defined as one between an entity that has acquired vaccines from an entity other than a vaccine producer, and transfers them to another entity. 


Transfer Type: Denotes whether the secondary arrangement is direct or through an intermediary, where direct is an arrangement between the donor and recipient while intermediary includes a third entity (such as COVAX) through which the arrangement occurs.


Recipient: Name of the entity receiving the vaccines. 


Recipient Region: Region for the recipient, as defined by the World Bank.


Recipient Income Level: Income level as defined by the World Bank.


GNI/capita (Atlas method) (current US$) : For the Recipient, based on World Bank data. 


GNI, Atlas method (current US$): For the Recipient, based on World Bank data (Atlas method).


Population: Based on World Bank data.


Population (in millions): Rounded population size. 


Doses/Capita: Number of committed doses/capita of Recipient.


Proportion of population: Proportion of the population that would be covered by the doses committed (taking into account number of doses required for each candidate). 


Notes: Free text tracking of relevant information on the arrangements.


Sources: URLs for all sources used for each arrangement




3. Missing data codes: 
“Not available,” NA (as abbreviated form of Not Available), and blanks are used to signify data that is not available or not relevant.