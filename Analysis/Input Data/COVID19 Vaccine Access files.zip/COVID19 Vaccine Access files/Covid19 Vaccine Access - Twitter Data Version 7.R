# Covid-19 vaccine data with rtweet

library(rtweet) # R package to use Twitter API
library(stringr)
library(dplyr)
library(openxlsx) 

# insert your Twitter developer credentials
consumer_key <- 'oZrA99PJNKhNvfip2ZUfQaCJc'
consumer_secret <- 'lXVSn6lznN9JEnSNKx0dKfJiQMyw2f58AMdNB49hqtziYjfMxe'
access_token <- '396539875-vwSfb2Ya3BkkaHAQv8yAuR6fS7OKkVPR9z3HCLom'
access_secret <- 'E87nXaUh57UsgQpaqmTohQc661XKVrnGRpq0CaRU1ULez'
# create token
token <- create_token("Covid-19 Vaccine Donations", consumer_key, consumer_secret, access_token = access_token, access_secret = access_secret)
token

# make multiple independent search queries (search query of no greater than 500 characters maximum)
# first search aiming at vaccine donations
tw1 <- Map(
  "search_tweets",
  c("(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Afghanistan OR Albania OR Algeria OR Samoa OR Andorra OR Angola OR Antigua OR Argentina OR Armenia OR Aruba OR Australia OR Austria OR Azerbaijan)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Bahamas OR Bahrain OR Bolivia OR \"Bosnia and Herzegovina\" OR Botswana OR Brazil OR Brunei OR Darussalam OR Bulgaria OR \"Burkina Faso\")",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Burundi OR \"Cabo Verde\" OR Cambodia OR Cameroon OR \"Channel Islands\" OR Chile OR China OR Colombia OR Comoros OR Congo OR \"Costa Rica\")",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Ivoire OR Croatia OR Cuba OR Curacao OR Cyprus OR \"Czech Republic\" OR Denmark OR Timor OR Ecuador OR Egypt OR \"El Salvador\")",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (\"Equatorial Guinea\" OR Eritrea OR Estonia OR Eswatini OR Ethiopia OR Faroe OR Fiji OR Finland OR France OR Polynesia OR Gabon OR Guam)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Gabon OR Guam OR Guatemala OR Guinea OR Bissau OR Guyana OR Haiti OR Honduras OR \"Hong Kong\" OR Hungary OR Iceland OR India OR Indonesia OR Iran)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Iraq OR Ireland OR \"Isle of Man\" OR Kenya OR Kiribati OR Kosovo OR Kuwait OR Kyrgyz OR Kyrgyzstan OR Lao OR Laos OR Latvia OR Lebanon OR Lesotho)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Liberia OR Libya OR Liechtenstein OR Madagascar OR Malawi OR Malaysia OR Maldives OR Mali OR Malta OR \"Marshall Islands\" OR Mauritania)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Mauritius OR Mexico OR Micronesia OR Moldova OR Monaco OR Mongolia OR Montenegro OR Morocco OR Mozambique OR Myanmar OR Burma OR Namibia OR Nauru)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Nepal OR Netherlands OR \"New Zealand\" OR Nicaragua OR Niger OR Nigeria OR Macedonia OR Mariana OR Norway OR Oman OR Pakistan OR Paraguay OR Peru)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Philippines OR Poland OR Portugal OR \"Puerto Rico\" OR Qatar OR Romania OR Russia OR Russian OR Rwanda OR \"Saint Kitts and Nevis\")",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (\"Saint Lucia\" OR \"Sao Tamo and Principe\" OR \"Saudi Arabia\" OR Senegal OR Serbia OR Seychelles OR \"Sierra Leone\" OR Singapore)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (\"Sint Maarten\" OR Slovak OR Slovakia OR Slovenia OR \"Solomon Islands\" OR \"Sri Lanka\" OR Kitts OR Lucia OR Martin OR Grenadines OR Sudan)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Suriname OR Swaziland OR Sweden OR Switzerland OR Syrian OR Syria OR Taiwan OR Tajikistan OR Tanzania OR Thailand OR Leste OR Tuvalu OR Uganda)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Ukraine OR \"United Arab Emirates\" OR \"United Kingdom\" OR UK OR \"United States\" OR US OR USA OR U.S. OR Uruguay OR Uzbekistan OR Vanuatu)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (\"Vatican City\" OR Palestine OR \"West Bank\" OR Gaza OR Caribbean OR Baltics OR Pacific OR Europe OR EU OR \"European Union\")",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (\"Latin America\" OR \"Middle East\" OR Bangladesh OR Barbados OR Belarus OR Belgium OR Belize OR Benin OR Bermuda OR Bhutan OR Canada OR Cayman)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (\"Cape Verde\" OR \"Central African Republic\" OR Chad OR Djibouti OR Dominica OR \"Dominican Republic\" OR Gambia OR Georgia OR Germany OR Ghana)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Gibraltar OR Greece OR Greenland OR Grenada OR Israel OR Italy OR Jamaica OR Japan OR Jordan OR Kazakhstan OR Lithuania OR Luxembourg OR Macao)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Macedonia OR Palau OR Panama OR \"Papua New Guinea\" OR \"Saint Vincent and the Grenadines\" OR Samoa OR \"San Marino\" OR Somalia)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Greece OR Greenland OR Grenada OR Israel OR Italy OR Jamaica OR Japan OR Jordan OR Kazakhstan OR Lithuania OR Luxembourg OR Macao OR Macedonia)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Somalia OR \"South Africa\" OR \"South Sudan\" OR Spain OR Togo OR Tonga OR \"Trinidad and Tobago\" OR Tunisia OR Turkey OR Turkmenistan)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (Venezuela OR Vietnam OR \"Virgin Islands\" OR Yemen OR Zambia OR Zimbabwe OR \"North America\" OR \"African Union\" OR Africa OR Asia OR Korea)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Donation OR donate  OR donated OR donating OR donates OR donation OR send OR sent OR delivery OR delivered OR deliver OR delivers OR delivering OR arrived OR arrive OR arriving OR arrival OR gift OR gifted OR gifting) -blood filter:verified (DRC OR U.K. OR E.U. OR COVAX OR CEPI OR \"UN Peacekeepers\")"
  ),
  n = 1000,
  since = "2021-09-27",
  include_rts = F, 
  retryonlimit = T
)

# second search aiming at vaccine purchases
tw2 <- Map(
  "search_tweets",
  c("(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Afghanistan OR Albania OR Algeria OR Samoa OR Andorra OR Angola OR Antigua)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Bahamas OR Bahrain OR Bolivia OR \"Bosnia and Herzegovina\" OR Botswana)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Burundi OR \"Cabo Verde\" OR Cambodia OR Cameroon OR \"Channel Islands\")",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Ivoire OR Croatia OR Cuba OR Curacao OR Cyprus OR \"Czech Republic\")",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (\"Equatorial Guinea\" OR Eritrea OR Estonia OR Eswatini OR Ethiopia OR Faroe)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Gabon OR Guam OR Guatemala OR Guinea OR Bissau OR Guyana OR Haiti OR Honduras)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Iraq OR Ireland OR \"Isle of Man\" OR Kenya OR Kiribati OR Kosovo OR Kuwait)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Liberia OR Libya OR Liechtenstein OR Madagascar OR Malawi OR Malaysia)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Mauritius OR Mexico OR Micronesia OR Moldova OR Monaco OR Mongolia)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Nepal OR Netherlands OR \"New Zealand\" OR Nicaragua OR Niger OR Nigeria)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Philippines OR Poland OR Portugal OR \"Puerto Rico\" OR Qatar OR Romania)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (\"Saint Lucia\" OR \"Sao Tamo and Principe\" OR \"Saudi Arabia\" OR Senegal)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (\"Sint Maarten\" OR Slovak OR Slovakia OR Slovenia OR \"Solomon Islands\")",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Suriname OR Swaziland OR Sweden OR Switzerland OR Syrian OR Syria OR Taiwan)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Ukraine OR \"United Arab Emirates\" OR \"United Kingdom\" OR UK)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (\"Vatican City\" OR Palestine OR \"West Bank\" OR Gaza OR Caribbean OR Baltics)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (\"Latin America\" OR \"Middle East\" OR Bangladesh OR Barbados OR Belarus)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (\"Cape Verde\" OR \"Central African Republic\" OR Chad OR Djibouti OR Dominica)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Gibraltar OR Greece OR Greenland OR Grenada OR Israel OR Italy OR Jamaica)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Macedonia OR Palau OR Panama OR \"Papua New Guinea\")",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Greece OR Greenland OR Grenada OR Israel OR Italy OR Jamaica OR Japan)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Somalia OR \"South Africa\" OR \"South Sudan\" OR Spain OR Togo OR Tonga)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Venezuela OR Vietnam OR \"Virgin Islands\" OR Yemen OR Zambia OR Zimbabwe)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (DRC OR \"U.K.\" OR \"E.U.\" OR COVAX OR CEPI OR \"UN Peacekeepers\")",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Australia OR Austria OR Azerbaijan  OR Bulgaria OR \"Burkina Faso\")",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Egypt OR \"El Salvador\"  OR Polynesia OR Gabon OR Guam  OR Iceland OR India)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Laos OR Latvia OR Lebanon OR Lesotho  OR \"Marshall Islands\" OR Mauritania)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Nauru  OR Oman OR Pakistan OR Paraguay OR Peru  OR \"Saint Kitts and Nevis\")",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Gambia OR Georgia OR Germany OR Ghana  OR Lithuania OR Luxembourg OR Macao)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Luxembourg OR Macao OR Macedonia  OR Tunisia OR Turkey OR Turkmenistan)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Korea OR Lucia OR Martin OR Grenadines OR Sudan  OR Thailand OR Leste)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Uzbekistan OR Vanuatu OR \"European Union\" OR Bermuda OR Bhutan OR Canada OR Cayman)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Argentina OR Armenia OR Aruba  OR Brazil OR Brunei OR Darussalam)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Denmark OR Timor OR Ecuador OR Fiji OR Finland OR France OR \"Hong Kong\" OR Hungary)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Kyrgyz OR Kyrgyzstan OR Maldives OR Mali OR Malta  OR Morocco OR Mozambique)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Macedonia OR Mariana OR Norway OR Russia OR Russian OR Rwanda OR Serbia OR Seychelles)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (\"Sri Lanka\" OR Kitts OR Tajikistan OR Tanzania OR US OR USA OR \"U.S.\")",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Pacific OR Europe OR EU OR Belgium OR Belize OR Benin OR \"Dominican Republic\")",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Japan OR Jordan OR Kazakhstan OR \"Saint Vincent and the Grenadines\" OR Samoa)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Jordan OR Kazakhstan OR Lithuania OR \"Trinidad and Tobago\" OR \"North America\")",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (\"Sri Lanka\" OR Kitts OR Comoros OR Congo OR \"Costa Rica\" OR Indonesia OR Iran  OR Lao)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (\"Sri Lanka\" OR Kitts OR Myanmar OR Burma OR Namibia  OR \"Sierra Leone\" OR Singapore)",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (\"San Marino\" OR Somalia OR \"African Union\" OR Africa OR Asia OR \"United States\")",
    "(COVID OR covid OR coronavirus OR covid19) (vaccine OR vaccine  OR vaccines) (Purchase OR secure OR secured OR secures OR reserve OR reserved OR reserves OR buy OR buys OR bought OR purchase OR purchases OR purchased OR sign OR signs OR signed OR agreement OR agreed OR deal OR contract OR supply OR provide OR procure OR procures OR procurement) -blood filter:verified (Tuvalu OR Uganda OR Uruguay OR Chile OR China OR Colombia OR Montenegro)"
    ),
  n = 1000,
  since = "2021-09-27",
  include_rts = F,
  retryrateonlimit = T
)

# combine the resulting list of data frames into a single data frame 
df1 <- bind_rows(tw1)
# same for second search
df2 <- bind_rows(tw2)
# combine the list items into a single data frame
newdf <- rbind(df1, df2)
class(newdf)

# check how many tweets without duplicates
noduplicates <- newdf[!duplicated(newdf$text),] 

# keep only the first 5 columns
df <- newdf[,c(1:5)] 
str(df)
# extract the tweet IDs into a separate column
url_pattern <- "http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+"
df$ContentURL <- str_extract(df$text, url_pattern)
df$TweetURL <- paste0("https://twitter.com/", df$screen_name)
df$TweetURL <- paste0(df$TweetURL, "/status/")
df$TweetURL <- paste0(df$TweetURL, df$status_id)
str(df$TweetURL)
class(df)

# get user data (e.g. the user description)
users <- users_data(newdf)
str(users)

# merge the tweet dataset and user dataset, keep only columns of interest
df <- merge(df, users, by = "user_id")
df <- df[, c(3:7,9:11)]
# remove all duplicated tweets (will keep different links with otherwise identical tweets)
df <- df[!duplicated(df$text),] # check if number of observations matches the data frame without duplicates above
# sort oldest to newest
str(df$created_at)
df <- df[order(df$created_at),]

# create hyperlinks and save as Excel file

# add new column that manually constructs Excel hyperlink formula
# note backslash is required for quotes to appear in Excel
df <- df %>%
  mutate(
    content_hyperlink = paste0(
      "HYPERLINK(\"",
      ContentURL,
      "\")"
    )
  )

df <- df %>%
  mutate(
    tweet_hyperlink = paste0(
      "HYPERLINK(\"",
      TweetURL,
      "\")"
    )
  )

# specify column as formula per openxlsx::writeFormula option #2
class(df$content_hyperlink) <- "formula"
class(df$tweet_hyperlink) <- "formula"
# create and write workbook
wb <- createWorkbook()
addWorksheet(wb, "df_sheet")
writeData(wb, "df_sheet", df)
saveWorkbook(wb, "Covid Vaccines Twitter Data.xlsx", overwrite = T)

